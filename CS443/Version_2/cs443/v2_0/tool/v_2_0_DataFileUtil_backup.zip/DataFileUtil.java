package cs443.v2_0.tool;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

import cs443.v1_0.tool.CloseUtil;

/**
 * @author YuyangHE
 * @date 2016��4��9��
 * @version 1.0
 * @since 2016��4��9��
 */
public class DataFileUtil
{
	public static Map<Integer, Double> readingConnectionWeight(File connectionWeightFile)
	{
		Map<Integer, Double> connectionWeightMap = new HashMap<Integer, Double>();

		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;

		int count = 1;
		String tmpReading = null;
		Double tmpWeight = null;

		try
		{
			fis = new FileInputStream(connectionWeightFile);
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);

			while (null != (tmpReading = br.readLine()))
			{
				tmpWeight = Str2DoubleUtil.Str2Double(tmpReading);

				if (null == tmpWeight)
				{
					continue;
				}

				connectionWeightMap.put(count, tmpWeight);

				tmpWeight = null;

				++count;
			}
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Connection weight file is not exist. Quit.");
			e.printStackTrace();
			return null;
		}
		catch (IOException e)
		{
			System.out.println("Reading error");
			e.printStackTrace();
		}
		finally
		{
			CloseUtil.closeAll(br, isr, fis);
		}

		return connectionWeightMap;
	}

	public static void recordingPotential(FileOutputStream fos, OutputStreamWriter osw, BufferedWriter bw,
	        File potentialRecordingFile, double currentPotential)
	{
		if (!potentialRecordingFile.exists())
		{
			System.out.println("Potential file is not exist. Creating a new one.");
			try
			{
				potentialRecordingFile.createNewFile();
			}
			catch (IOException e)
			{
				System.out.println("Potential file creation failed.");
				e.printStackTrace();
			}
		}

		try
		{
			fos = new FileOutputStream(potentialRecordingFile, true);
			osw = new OutputStreamWriter(fos);
			bw = new BufferedWriter(osw);

			bw.write(currentPotential + "");
			bw.newLine();
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Finding file error.");
			e.printStackTrace();
		}
		catch (IOException e)
		{
			System.out.println("Writting error.");
			e.printStackTrace();
		}
		finally
		{
			CloseUtil.closeAll(bw, osw, fos);
		}
	}
}
