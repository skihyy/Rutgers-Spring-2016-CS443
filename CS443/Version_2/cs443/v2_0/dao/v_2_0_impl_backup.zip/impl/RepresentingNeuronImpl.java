package cs443.v2_0.dao.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import cs443.v2_0.dao.NeuronFunctionDao;
import cs443.v2_0.tool.DataFileUtil;
import cs443.v2_0.tool.SendMessageUtil;
import cs443.v2_0.vo.Constant;
import cs443.v2_0.vo.Neuron;
import cs443.v2_0.vo.Spike;

/**
 * The function of a representing neuron.
 * 
 * @author YuyangHE
 * @date 2016��4��3��
 * @version 2.0
 * @since 2016��4��3��
 */
public class RepresentingNeuronImpl extends Neuron implements NeuronFunctionDao
{
	/**
	 * A spike train used as the input. Define that one representing neuron can
	 * only receive one spike train as input.
	 */
	private List<Spike> spikeTrain;

	/**
	 * weight of connections with other neurons
	 */
	private File connectionWeightFile = null;

	/**
	 * used for data collecting, will record its current
	 */
	private File potentialRecordingFile = null;

	/**
	 * these three output is used to record potential of this neuron
	 */
	private FileOutputStream fos = null;
	private OutputStreamWriter osw = null;
	private BufferedWriter bw = null;

	/**
	 * Constructors of RepresentingNeuronImpl.
	 * 
	 * @param id
	 *            The ID of current neuron
	 */
	public RepresentingNeuronImpl(int id)
	{
		this.id = id;
		this.resetingPotential = Constant.RESETING_POTENTIAL;
		this.threshold = Constant.THRESHOLD;

		this.connectionWeightFile = new File(Constant.ROOT_DATA_PATH + File.separator + Constant.REPRESENTING_LAYER_PATH
		        + File.separator + Constant.CONNECTION_WEIGHT_FILE_PREFIX + id + Constant.FILE_SUFFIX);

		this.potentialRecordingFile = new File(
		        Constant.ROOT_DATA_PATH + File.separator + Constant.REPRESENTING_LAYER_PATH + File.separator
		                + Constant.POTENTIAL_FILE_PREFIX + id + Constant.FILE_SUFFIX);

		initialization();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cs443.v2_0.dao.NeuronFunctionDao#initialization(int)
	 */
	@Override
	public void initialization()
	{
		this.connectionWeightMap = DataFileUtil.readingConnectionWeight(this.connectionWeightFile);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cs443.v2_0.dao.NeuronFunctionDao#update(double)
	 */
	@Override
	public void update(double time)
	{
		// get information get I
		double current = getCurrent();

		this.currentPotential = getPotential(current);

		if (Constant.THRESHOLD <= this.currentPotential)
		{
			this.spike();
			this.recordPotential();
			this.currentPotential = Constant.RESETING_POTENTIAL;
		}
		else
		{
			this.recordPotential();
		}
	}

	/**
	 * Equivalent to <code>sumInputs()</code> in the lecture notes.
	 * 
	 * @return
	 */
	private double getCurrent()
	{
		int current = 0;

		for (Spike spike : this.spikeTrain)
		{
			if (spike.isFire())
			{
				current += spike.getWeight();
			}
		}

		return current;
	}

	/**
	 * From Izhikevich implementation where dv/dt = 0.04v^2 + 5v + 140 - u + I.
	 * In this case, simply set u = self.b * v where self.b = 0.2 and v is the
	 * potential.
	 */
	private double getPotential(double current)
	{
		return 0.04 * Math.pow(this.currentPotential, 2) + 5 * this.currentPotential + 140 - 0.2 * this.currentPotential
		        + current;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cs443.v2_0.dao.NeuronFunctionDao#spike()
	 */
	@Override
	public void spike()
	{
		System.out.println("Spiking!");

		// if it spikes
		// send this number to the comparing neuron
		this.sendMessage();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cs443.v2_0.dao.NeuronFunctionDao#sendMessage()
	 */
	@Override
	public void sendMessage()
	{
		int destinationID = getDestinationID();

		SendMessageUtil.sendMessage(destinationID);
	}

	/**
	 * This id is the neuron in comparing layer that has the largest connection
	 * weight with current neuron.
	 */
	private int getDestinationID()
	{
		int id = -1;
		double maxPotential = -1, tmpPotential = -1;
		;

		Set<Entry<Integer, Double>> connectionWeight = this.connectionWeightMap.entrySet();

		for (Entry<Integer, Double> oneConnection : connectionWeight)
		{
			tmpPotential = oneConnection.getValue();
			if (tmpPotential > maxPotential)
			{
				maxPotential = tmpPotential;
				id = oneConnection.getKey();
			}
		}

		return id;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cs443.v2_0.dao.NeuronFunctionDao#recordPotential()
	 */
	@Override
	public void recordPotential()
	{
		DataFileUtil.recordingPotential(fos, osw, bw, this.potentialRecordingFile, this.currentPotential);
	}

}
