package cs443.v2_0.dao.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.List;

import cs443.v2_0.dao.NeuronFunctionDao;
import cs443.v2_0.tool.DataFileUtil;
import cs443.v2_0.vo.Constant;
import cs443.v2_0.vo.Neuron;
import cs443.v2_0.vo.Spike;

/**
 * The function of a comparing neuron.
 * 
 * @author YuyangHE
 * @date 2016��4��9��
 * @version 1.0
 * @since 2016��4��9��
 */
public class ComparingNeuronImpl extends Neuron implements NeuronFunctionDao
{
	/**
	 * A spike train used as the input. Define that one comparing neuron can
	 * receive many spikes train as input.
	 */
	private List<List<Spike>> spikeTrain;

	/**
	 * weight of connections with other neurons
	 */
	private File connectionWeightFile = null;

	/**
	 * used for data collecting, will record its current
	 */
	private File potentialRecordingFile = null;

	/**
	 * these three output is used to record potential of this neuron
	 */
	private FileOutputStream fos = null;
	private OutputStreamWriter osw = null;
	private BufferedWriter bw = null;

	/**
	 * Constructors of RepresentingNeuronImpl.
	 * 
	 * @param id
	 *            The ID of current neuron
	 */
	public ComparingNeuronImpl(int id)
	{
		this.id = id;
		this.resetingPotential = Constant.RESETING_POTENTIAL;
		this.threshold = Constant.THRESHOLD;

		this.connectionWeightFile = new File(Constant.ROOT_DATA_PATH + File.separator + Constant.REPRESENTING_LAYER_PATH
		        + File.separator + Constant.CONNECTION_WEIGHT_FILE_PREFIX + id + Constant.FILE_SUFFIX);

		this.potentialRecordingFile = new File(
		        Constant.ROOT_DATA_PATH + File.separator + Constant.REPRESENTING_LAYER_PATH + File.separator
		                + Constant.POTENTIAL_FILE_PREFIX + id + Constant.FILE_SUFFIX);

		initialization();
	}

	/* (non-Javadoc)
	 * @see cs443.v2_0.dao.NeuronFunctionDao#initialization()
	 */
	@Override
	public void initialization()
	{
		this.connectionWeightMap = DataFileUtil.readingConnectionWeight(this.connectionWeightFile);
	}

	/* (non-Javadoc)
	 * @see cs443.v2_0.dao.NeuronFunctionDao#update(double)
	 */
	@Override
	public void update(double time)
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see cs443.v2_0.dao.NeuronFunctionDao#spike()
	 */
	@Override
	public void spike()
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see cs443.v2_0.dao.NeuronFunctionDao#sendMessage()
	 */
	@Override
	public void sendMessage()
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see cs443.v2_0.dao.NeuronFunctionDao#recordPotential()
	 */
	@Override
	public void recordPotential()
	{
		// TODO Auto-generated method stub
		
	}

}
